// Copyright (c) 2024 CYBERKOALA LLC

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerState.h"
#include "PS_PlayerState.generated.h"

/**
 * 
 */
UCLASS()
class PROJECTSLICK_DUNGEON_API APS_PlayerState : public APlayerState
{
	GENERATED_BODY()
	
};
