// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "PS_GameInstance.generated.h"

/**
 * 
 */
UCLASS()
class PROJECTSLICK_DUNGEON_API UPS_GameInstance : public UGameInstance
{
	GENERATED_BODY()
	
};
