// Copyright (c) 2024 CYBERKOALA LLC

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "PS_Enemy.generated.h"

UCLASS()
class PROJECTSLICK_DUNGEON_API APS_Enemy : public ACharacter
{
	GENERATED_BODY()

private:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Health", meta = (AllowPrivateAccess = "true"))
	float Health = 5.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Pickup", meta = (AllowPrivateAccess = "true"))
	TSubclassOf<class APS_BasePickup> SpawnedPickup;


public:
	APS_Enemy();

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enemy AI")
	float PatrolSpeed = 160.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enemy AI")
	float ChaseSpeed = 360.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enemy AI")
	float PatrolRadius = 60000.0f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Enemy AI", meta = (AllowPrivateAccess = "true"))
	float AlertRadius = 80000.0f;



protected:
	virtual void BeginPlay() override;

	UFUNCTION()
	void OnHearNoise(APawn* PawnInstigator, const FVector& Location, float Volume);

	UFUNCTION()
	void OnDamage(AActor* DamagedActor, float Damage, const UDamageType* DamageType, AController* InstigatedBy, AActor* DamageCauser);

private:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Enemy Perception", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<class UAIPerceptionComponent> AiPerception;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Enemy Perception", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<class UPawnSensingComponent> PawnSense;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Enemy Perception", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<class USphereComponent> Collision;

	UPROPERTY()
	FVector PatrolLocation;

public:
	virtual void Tick(float DeltaTime) override;

	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	UFUNCTION(BlueprintCallable, Category = "Enemy AI")
	void SetNextPatrolLocation();

	UFUNCTION(BlueprintCallable, Category = "Enemy AI")
	void Chase(APawn* Pawn);

	UFUNCTION(BlueprintCallable, Category = "Enemy AI")
	void		 GoToLocation(const FVector& Location);

	virtual void PostInitializeComponents() override;

	FORCEINLINE UPawnSensingComponent* GetPawnSense() const { return PawnSense; }

	FORCEINLINE UAIPerceptionComponent* GetAiPerception() const { return AiPerception; }
	FORCEINLINE USphereComponent*	   GetCollision() const { return Collision; }

	UFUNCTION()
	void OnPerceptionUpdated(const TArray<AActor*>& UpdatedActors);

	UFUNCTION()
	void OnPawnDetected(APawn* Pawn);

	UFUNCTION()
	void OnBeginOverlap(AActor* OverlappedActor, AActor* OtherActor);
};
