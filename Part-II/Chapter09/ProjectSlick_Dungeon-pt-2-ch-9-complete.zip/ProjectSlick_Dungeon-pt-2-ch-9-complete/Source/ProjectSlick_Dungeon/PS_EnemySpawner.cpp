// Copyright (c) 2024 CYBERKOALA LLC

#include "PS_EnemySpawner.h"
#include "PS_Enemy.h"
#include "Components/BoxComponent.h"
#include <Kismet/KismetMathLibrary.h>

// Sets default values
APS_EnemySpawner::APS_EnemySpawner()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	SpawnArea = CreateDefaultSubobject<UBoxComponent>(TEXT("Spawn Area"));
	SpawnArea->SetupAttachment(RootComponent);
	SpawnArea->SetBoxExtent(FVector(1000.0f, 1000.0f, 100.0f));
}

// Called when the game starts or when spawned
void APS_EnemySpawner::BeginPlay()
{
	Super::BeginPlay();
	if (SpawnableEnemies.IsEmpty())
		return;
	if (GetLocalRole() != ROLE_Authority)
		return;
	for (int32 i = 0; i < NumEneimesAtStart; i++)
	{
		Spawn();
	}
	GetWorldTimerManager().SetTimer(SpawnTimerHandle, this, &APS_EnemySpawner::Spawn, SpawnDelay, true, SpawnDelay);
}

void APS_EnemySpawner::Spawn()
{
	if (SpawnableEnemies.IsEmpty())
		return;

	// Randomly choose a enemy type
	//const int32					 EnemyIndex = FMath::RandRange(0, SpawnableEnemies.Num() - 1);
	//const TSubclassOf<APS_Enemy> EnemyToSpawn = SpawnableEnemies[EnemyIndex];

	//// Determine a random spawn location within the SpawnArea
	//const FVector SpawnLocation = UKismetMathLibrary::RandomPointInBoundingBox(
	//	SpawnArea->Bounds.Origin, SpawnArea->Bounds.BoxExtent);

	//// Spawn the enemy
	//GetWorld()->SpawnActor<APS_Enemy>(EnemyToSpawn, SpawnLocation, FRotator::ZeroRotator);

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButDontSpawnIfColliding;
	auto Enemy = SpawnableEnemies[FMath::RandRange(0, SpawnableEnemies.Num() - 1)];
	const auto Rotation = FRotator(0.0f, FMath::RandRange(0.0f, 360.0f), 0.0f);
	const auto Location = SpawnArea->GetComponentLocation() + FVector(FMath::RandRange(-SpawnArea->GetScaledBoxExtent().X, SpawnArea->GetScaledBoxExtent().X), FMath::RandRange(-SpawnArea->GetScaledBoxExtent().Y, SpawnArea->GetScaledBoxExtent().Y), 0.0f);
	GetWorld()->SpawnActor<APS_Enemy>(Enemy, Location, Rotation, SpawnParams);
}

// Called every frame
void APS_EnemySpawner::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}
