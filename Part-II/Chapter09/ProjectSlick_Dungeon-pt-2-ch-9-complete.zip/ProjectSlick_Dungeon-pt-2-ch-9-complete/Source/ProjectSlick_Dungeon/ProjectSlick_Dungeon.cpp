// Copyright Epic Games, Inc. All Rights Reserved.

#include "ProjectSlick_Dungeon.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, ProjectSlick_Dungeon, "ProjectSlick_Dungeon" );
