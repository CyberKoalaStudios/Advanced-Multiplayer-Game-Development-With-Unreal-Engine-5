// Copyright (c) 2024 CYBERKOALA LLC

#include "PS_GameMode.h"
#include "PS_PlayerController.h"
#include "PS_PlayerState.h"
#include "PS_Character.h"
#include "UObject/ConstructorHelpers.h"
#include "PS_Enemy.h"
#include "Kismet/GameplayStatics.h"
#include "PS_GameState.h"
#include "PS_CustomLogs.h"

APS_GameMode::APS_GameMode()
{
	GameStateClass = APS_GameState::StaticClass();

	PlayerStateClass = APS_PlayerState::StaticClass();
	PlayerControllerClass = APS_PlayerController::StaticClass();
	static ConstructorHelpers::FClassFinder<APawn> PlayerPawnBPClass(TEXT("/Game/ProjectSlick/Characters/BP_Character"));
	if (PlayerPawnBPClass.Class != nullptr)
	{
		DefaultPawnClass = PlayerPawnBPClass.Class;
	}
}

void APS_GameMode::AlertEnemies(AActor* AlertInstigator, const FVector& Location, float Radius)
{
	UE_LOG(LogProjectSlick, Display, TEXT("Alerting Enemies"));
	TArray<AActor*> Enemies;
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), APS_Enemy::StaticClass(), Enemies);
	for (const auto Enemy : Enemies)
	{
		if (AlertInstigator == Enemy)
			continue;
		if (const auto Distance = FVector::Distance(AlertInstigator->GetActorLocation(), Enemy->GetActorLocation()); Distance < Radius)
		{
			if (const auto EnemyCharacter = Cast<APS_Enemy>(Enemy))
			{
				EnemyCharacter->GoToLocation(Location);
			}
		}
	}
}
