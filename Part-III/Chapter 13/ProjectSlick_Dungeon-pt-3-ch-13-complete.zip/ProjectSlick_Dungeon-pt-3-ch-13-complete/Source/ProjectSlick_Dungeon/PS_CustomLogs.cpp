// Copyright (c) 2024 CYBERKOALA LLC


#include "PS_CustomLogs.h"

DEFINE_LOG_CATEGORY(LogProjectSlick);