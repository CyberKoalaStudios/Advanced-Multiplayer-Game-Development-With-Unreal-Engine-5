# ProjectSlick


Use the following code to cast the objects into Project Slick objects:
```cpp

AProjectSlickPlayerController* projectSlickPlayerController = Cast<AProjectSlickPlayerController>(playerController);
AProjectSlickGameMode* projectSlickGameMode = Cast<AProjectSlickGameMode*> gameMode;
AProjectSlickGameStateBase* projectSlickGameState = Cast<AProjectSlickGameStateBase*>(gameState);
UProjectSlickGameInstance* projectSlickGameInstance = Cast<UProjectSlickGameInstance>(gameInstance);
```


Website: https://learn.cyberkoala.ru/


https://unreal.gg-labs.com/wiki-archives/macros-and-data-types/interfaces-in-c++