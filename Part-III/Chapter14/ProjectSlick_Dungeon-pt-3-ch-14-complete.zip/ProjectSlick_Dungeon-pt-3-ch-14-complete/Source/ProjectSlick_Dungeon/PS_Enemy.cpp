// Copyright (c) 2024 CYBERKOALA LLC

#include "PS_Enemy.h"
#include "AIController.h"
#include "NavigationSystem.h"
#include "PS_Character.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include <Perception/AIPerceptionComponent.h>
#include "Perception/PawnSensingComponent.h"
#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "Components/SphereComponent.h"
#include <Perception/AISenseConfig_Sight.h>
#include <Perception/AISenseConfig_Hearing.h>
#include "PS_GameMode.h"
#include "PS_BasePickup.h"

APS_Enemy::APS_Enemy()
{
	PrimaryActorTick.bCanEverTick = true;

	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;
	AutoPossessAI = EAutoPossessAI::PlacedInWorldOrSpawned;
	AIControllerClass = AAIController::StaticClass();

	PawnSense = CreateDefaultSubobject<UPawnSensingComponent>(TEXT("PawnSense"));
	PawnSense->SensingInterval = .8f;
	PawnSense->SetPeripheralVisionAngle(60.f);
	PawnSense->SightRadius = 2000.f;

	PawnSense->HearingThreshold = 400.f;
	PawnSense->LOSHearingThreshold = 800.f;

	AiPerception = CreateDefaultSubobject<UAIPerceptionComponent>(TEXT("AIPerceptionComponent"));

	UAISenseConfig_Sight* SightConfig = CreateDefaultSubobject<UAISenseConfig_Sight>(TEXT("Sight Config"));
	SightConfig->SightRadius = 2000.0f;
	SightConfig->LoseSightRadius = 2500.0f;
	SightConfig->PeripheralVisionAngleDegrees = 60.f;

	UAISenseConfig_Hearing* HearingConfig = CreateDefaultSubobject<UAISenseConfig_Hearing>(TEXT("Hearing Config"));
	HearingConfig->HearingRange = 800.f;

	AiPerception->ConfigureSense(*SightConfig);
	AiPerception->ConfigureSense(*HearingConfig);
	AiPerception->SetDominantSense(UAISense_Sight::StaticClass());

	Collision = CreateDefaultSubobject<USphereComponent>(TEXT("Collision"));
	Collision->SetSphereRadius(100);
	Collision->SetupAttachment(RootComponent);

	GetCapsuleComponent()->InitCapsuleSize(60.f, 95.0f);
	GetCapsuleComponent()->SetGenerateOverlapEvents(true);
	GetMesh()->SetRelativeLocation(FVector(0.f, 0.f, -90.f));

	static ConstructorHelpers::FObjectFinder<USkeletalMesh> SkeletalMeshAsset(TEXT("/Game/KayKit/Skeletons/skeleton_minion"));
	if (SkeletalMeshAsset.Succeeded())
	{
		GetMesh()->SetSkeletalMesh(SkeletalMeshAsset.Object);
	}
	GetCharacterMovement()->bOrientRotationToMovement = true;
	GetCharacterMovement()->RotationRate = FRotator(0.0f, 600.0f, 0.0f);
	GetCharacterMovement()->MaxWalkSpeed = 190.f;
	GetCharacterMovement()->MinAnalogWalkSpeed = 30.f;
	GetCharacterMovement()->BrakingDecelerationWalking = 2000.f;

	static ConstructorHelpers::FClassFinder<APS_BasePickup> SpawnedPickupAsset(TEXT("/Game/ProjectSlick/Core/BP_GoldCoinPickup"));
	if (SpawnedPickupAsset.Succeeded())
	{
		SpawnedPickup = SpawnedPickupAsset.Class;
	}
}

void APS_Enemy::BeginPlay()
{
	Super::BeginPlay();
	SetNextPatrolLocation();
}

void APS_Enemy::OnHearNoise(APawn* PawnInstigator, const FVector& Location, float Volume)
{
	GEngine->AddOnScreenDebugMessage(-1, 4.f, FColor::Yellow, TEXT("Noise detected!"));
	GoToLocation(Location);
	UAIBlueprintHelperLibrary::SimpleMoveToLocation(GetController(), PatrolLocation);
}

void APS_Enemy::OnDamage(AActor* DamagedActor, float Damage, const UDamageType* DamageType, AController* InstigatedBy, AActor* DamageCauser)
{
	Health -= Damage;
	if (Health > 0)
		return;
	if (SpawnedPickup)
	{
		GetWorld()->SpawnActor<APS_BasePickup>(SpawnedPickup, GetActorLocation(), GetActorRotation());
	}
	Destroy();
}

void APS_Enemy::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (GetLocalRole() != ROLE_Authority)
		return;
	if (GetMovementComponent()->GetMaxSpeed() == ChaseSpeed)
		return;
	if ((GetActorLocation() - PatrolLocation).Size() < 500.f)
	{
		SetNextPatrolLocation();
	}
}

void APS_Enemy::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}

void APS_Enemy::SetNextPatrolLocation()
{
	if (GetLocalRole() != ROLE_Authority)
		return;
	GetCharacterMovement()->MaxWalkSpeed = PatrolSpeed;
	const auto LocationFound = UNavigationSystemV1::K2_GetRandomReachablePointInRadius(
		this, GetActorLocation(), PatrolLocation, PatrolRadius);
	if (LocationFound)
	{
		UAIBlueprintHelperLibrary::SimpleMoveToLocation(GetController(), PatrolLocation);
	}
}

void APS_Enemy::Chase(APawn* Pawn)
{
	if (GetLocalRole() != ROLE_Authority)
		return;

	if (!Pawn)
		return;

	GetCharacterMovement()->MaxWalkSpeed = ChaseSpeed;

	UAIBlueprintHelperLibrary::SimpleMoveToActor(GetController(), Pawn);

	DrawDebugSphere(GetWorld(), Pawn->GetActorLocation(), 26.f, 14, FColor::Red, true, 10.f, 0, 2.f);

	if (const auto GameMode = Cast<APS_GameMode>(GetWorld()->GetAuthGameMode()))
	{
		GameMode->AlertEnemies(this, Pawn->GetActorLocation(), AlertRadius);
	}
}

void APS_Enemy::GoToLocation(const FVector& Location)
{
	PatrolLocation = Location;
	UAIBlueprintHelperLibrary::SimpleMoveToLocation(GetController(), PatrolLocation);
}

void APS_Enemy::PostInitializeComponents()
{
	Super::PostInitializeComponents();
	if (GetLocalRole() != ROLE_Authority)
		return;
	OnActorBeginOverlap.AddDynamic(this, &APS_Enemy::OnBeginOverlap);

	GetPawnSense()->OnSeePawn.AddDynamic(this, &APS_Enemy::OnPawnDetected);
	GetPawnSense()->OnHearNoise.AddDynamic(this, &APS_Enemy::OnHearNoise);
	OnTakeAnyDamage.AddDynamic(this, &APS_Enemy::OnDamage);

	GetAiPerception()->OnPerceptionUpdated.AddDynamic(this, &APS_Enemy::OnPerceptionUpdated);
}

void APS_Enemy::OnPerceptionUpdated(const TArray<AActor*>& UpdatedActors)
{
	for (AActor* Actor : UpdatedActors)
	{
		APawn* Pawn = Cast<APawn>(Actor);
		if (!Pawn)
			continue;

		if (!Pawn->IsA<APS_Character>())
			return;

		GEngine->AddOnScreenDebugMessage(-1, 6.f, FColor::Red, TEXT("Perception: Player character detected!"));

		if (GetCharacterMovement()->MaxWalkSpeed != ChaseSpeed)
		{
			GEngine->AddOnScreenDebugMessage(-1, 6.f, FColor::Red, TEXT("Chasing!"));
			Chase(Pawn);
		}
	}
}

void APS_Enemy::OnPawnDetected(APawn* Pawn)
{
	if (!Pawn->IsA<APS_Character>())
		return;
	GEngine->AddOnScreenDebugMessage(-1, 6.f, FColor::Red, TEXT("PawnSensing: Player character detected!"));
	if (GetCharacterMovement()->MaxWalkSpeed != ChaseSpeed)
	{
		Chase(Pawn);
	}
}

void APS_Enemy::OnBeginOverlap(AActor* OverlappedActor, AActor* OtherActor)
{
	if (!OtherActor->IsA<APS_Character>())
		return;
	GEngine->AddOnScreenDebugMessage(-1, 6.f, FColor::Yellow, TEXT("Player Character captured!"));
}
