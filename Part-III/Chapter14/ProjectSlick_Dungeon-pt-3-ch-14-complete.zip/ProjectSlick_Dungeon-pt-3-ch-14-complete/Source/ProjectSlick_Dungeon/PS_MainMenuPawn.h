// Copyright (c) 2024 CYBERKOALA LLC

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
 
#include "PS_MainMenuPawn.generated.h"

struct FPS_CharacterSkins;

UCLASS()
class PROJECTSLICK_DUNGEON_API APS_MainMenuPawn : public APawn
{
	GENERATED_BODY()

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Arrow", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<class UArrowComponent> Arrow;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<class UCameraComponent> Camera;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera", meta = (AllowPrivateAccess = "true"))
	TObjectPtr<USkeletalMeshComponent> Mesh;

public:
	// Sets default values for this pawn's properties
	APS_MainMenuPawn();

	FORCEINLINE FPS_CharacterSkins* GetCharacterSkin() const { return CharacterSkin; }

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	FORCEINLINE UArrowComponent*		GetArrow() const { return Arrow; }
	FORCEINLINE UCameraComponent*		GetCamera() const { return Camera; }
	FORCEINLINE USkeletalMeshComponent* GetMesh() const { return Mesh; }
	void								RandomizeCharacterSkin();

private: 
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Character Data", meta = (AllowPrivateAccess = "true"))
	class UDataTable* CharacterSkinDataTable;

	struct FPS_CharacterSkins* CharacterSkin;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

};
