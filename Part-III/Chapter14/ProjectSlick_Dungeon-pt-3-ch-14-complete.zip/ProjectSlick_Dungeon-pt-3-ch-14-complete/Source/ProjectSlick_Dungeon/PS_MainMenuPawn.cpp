// Copyright (c) 2024 CYBERKOALA LLC


#include "PS_MainMenuPawn.h"

#include "Camera/CameraComponent.h"
#include "Components/ArrowComponent.h"
#include "PS_CharacterSkins.h"
#include "PS_GameInstance.h"

// Sets default values
APS_MainMenuPawn::APS_MainMenuPawn()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	Arrow = CreateDefaultSubobject<UArrowComponent>(TEXT("Arrow"));
	RootComponent = Arrow;
	Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
	Camera->SetupAttachment(RootComponent);
	Camera->SetRelativeLocation(FVector(450.f, 90.f, 160.f));
	Camera->SetRelativeRotation(FRotator(0.0f, -10.0f, 180.f));
	Mesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("Mesh"));
	Mesh->SetupAttachment(RootComponent);
	Camera->SetRelativeLocation(FVector(0.f, -30.f, 90.f));
	static ConstructorHelpers::FObjectFinder<USkeletalMesh> SkeletalMeshAsset(TEXT("/Game/KayKit/Characters/rogue"));
	if (SkeletalMeshAsset.Succeeded())
	{
		Mesh->SetSkeletalMesh(SkeletalMeshAsset.Object);
	}
}

// Called when the game starts or when spawned
void APS_MainMenuPawn::BeginPlay()
{
	Super::BeginPlay();

	if (IsLocallyControlled())
	{
		RandomizeCharacterSkin();
	}
}

void APS_MainMenuPawn::RandomizeCharacterSkin()
{
	if (CharacterSkinDataTable)
	{
		TArray<FPS_CharacterSkins*> CharacterSkinsRows;
		CharacterSkinDataTable->GetAllRows<FPS_CharacterSkins>(TEXT("PS_Character"), CharacterSkinsRows);

		if (CharacterSkinsRows.Num() > 0)
		{
			const auto NewIndex = FMath::RandRange(0, CharacterSkinsRows.Num() - 1);
			CharacterSkin = CharacterSkinsRows[NewIndex];

			Mesh->SetMaterial(4, CharacterSkin->Material4);
			Mesh->SetMaterial(0, CharacterSkin->Material0);
			Mesh->SetMaterial(1, CharacterSkin->Material1);
			Mesh->SetMaterial(2, CharacterSkin->Material2);

			if (const auto GameInstance = Cast<UPS_GameInstance>(GetGameInstance()))
			{
				GameInstance->SkinIndex = NewIndex;
			}
		}
	}
}

// Called every frame
void APS_MainMenuPawn::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void APS_MainMenuPawn::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

