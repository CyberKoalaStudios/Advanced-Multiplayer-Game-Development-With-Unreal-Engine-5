// Copyright (c) 2024 CYBERKOALA LLC

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataTable.h"
#include "PS_CharacterSkins.generated.h"

USTRUCT(BlueprintType)
struct PROJECTSLICK_DUNGEON_API FPS_CharacterSkins : public FTableRowBase
{
	GENERATED_BODY()
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	UMaterialInterface* Material4;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	UMaterialInterface* Material0;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	UMaterialInterface* Material1;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	UMaterialInterface* Material2;
};
 